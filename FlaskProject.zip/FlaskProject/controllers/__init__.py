from flask import Blueprint
bpp = Blueprint("bpp", __name__)