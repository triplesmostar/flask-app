from flask_sqlalchemy import SQLAlchemy
import logging

logger = logging.getLogger("FlaskProject")
db = SQLAlchemy()
